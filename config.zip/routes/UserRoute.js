const router=require("express").Router();
const UserController=require("../Controller/UserController")


router.post("/",UserController.create)
router.get("/",UserController.find)
router.delete("/:id",UserController.trash)
router.patch("/:id",UserController.update)



module.exports=router;