const { Schema, default: mongoose, model } = require("mongoose")

const Format={
    type:String,
    trim:true,
    required:true
}

const UserModel= new Schema({
    User_name:{
        ...Format
    },
    User_email:{
        ...Format,
        unique:true["email id alredy exist"],

    },
    User_mobile:{
        type:Number,
        trim:true,
        required:true
    },
    User_address:{
        ...Format
    },
    Pro_id:{
        type:mongoose.Types.ObjectId,
        ref:"Products"
    },
   

},{
    timestamps:true
})
const User=model("UserData",UserModel)
module.exports=User